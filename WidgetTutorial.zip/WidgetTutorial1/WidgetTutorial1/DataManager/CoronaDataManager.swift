import Combine
import Foundation

struct JSONGlobalCoronaInfo: Decodable {
    let NewConfirmed: Int
    let TotalConfirmed: Int
    let NewDeaths: Int
    let TotalDeaths: Int
    let NewRecovered: Int
    let TotalRecovered: Int
}
struct JSONCountryCoronoInfo: Decodable {
    let Country: String
    let CountryCode: String
    let Slug: String
    let NewConfirmed: Int
    let TotalConfirmed: Int
    let NewDeaths: Int
    let TotalDeaths: Int
    let NewRecovered: Int
    let TotalRecovered: Int
    let Date: String
    let Premium: [String: String]?
}
struct JSONCoronaInfo: Decodable {
    let Message: String
    let Global: JSONGlobalCoronaInfo
    let Countries: [JSONCountryCoronoInfo]
}

class CoronaDataManager {
    let url = "https://api.covid19api.com/summary"
    func loadDataFromServer(completion: @escaping (JSONCoronaInfo)->Void) {
        guard let url = URL.init(string: url) else {
            print("url is invalid")
            return
        }
        // 2
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                if error != nil {
                    print(error!.localizedDescription)
                }

                guard let data = data else {
                    print("error parsing data")
                    return
                }
                do {
                    // 3
                    //Decode data
                     let parsedData =  try JSONDecoder().decode(JSONCoronaInfo.self, from: data)


                    // 4
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        completion(parsedData)
                    }

                } catch(let error) {
                    print(error)
                }
                // 5
                }.resume()
    }
    
}

