import SwiftUI
import WidgetKit

struct ContentView: View {
    var body: some View {
        Text("There is nothing here")
            .font(.title)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
