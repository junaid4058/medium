import WidgetKit
import SwiftUI

struct CoronaInfoEntry: TimelineEntry {
    var date: Date
    var coronaInfo: CoronaInfo
}


struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> CoronaInfoEntry {
        return CoronaInfoEntry.previewData
    }
    
    func getSnapshot(in context: Context, completion: @escaping (CoronaInfoEntry) -> Void) {
        let entry = CoronaInfoEntry(
            date: Date(),
            coronaInfo: CoronaInfo(
                deathCount: 4,
                infectedCount: 5,
                recoveryCount: 6))
        completion(entry)
        
    }
    
    func getTimeline(in context: Context, completion: @escaping (Timeline<CoronaInfoEntry>) -> Void) {
        
        let date = Date()
        let dataManager = CoronaDataManager()
        
        dataManager.loadDataFromServer { (coronaInfo) in
            let globalCoronaInfo = coronaInfo.Global
            let entry = CoronaInfoEntry(
                date: date,
                coronaInfo: CoronaInfo(
                    deathCount: globalCoronaInfo.TotalDeaths,
                    infectedCount: globalCoronaInfo.TotalConfirmed,
                    recoveryCount: globalCoronaInfo.TotalRecovered))
            
            let timeline = Timeline(entries: [entry], policy: .atEnd)
            
            completion(timeline)
        }
    }
}

@main
struct CoronaWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "name",
                            provider: Provider(),
                            content: { (entry)  in
                                CoronaUpdateView.init(coronaInfo: entry.coronaInfo)
                            })
                .configurationDisplayName("DisplayName")
                .description("Description")
                .supportedFamilies([.systemSmall,.systemMedium])
    }
}

//It's just an example and not related to code
extension CoronaInfoEntry {
    static var previewData: CoronaInfoEntry {
        return CoronaInfoEntry(
            date: Date(),
            coronaInfo: CoronaInfo(
                deathCount: 100,
                infectedCount: 20,
                recoveryCount: 300))
    }
}

struct CoronaWidget_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            CoronaUpdateView(coronaInfo: CoronaInfoEntry.previewData.coronaInfo)
        }
        .previewContext(WidgetPreviewContext.init(family: .systemMedium))
    }
}
