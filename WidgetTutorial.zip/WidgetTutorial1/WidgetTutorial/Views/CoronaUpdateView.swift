import SwiftUI
import WidgetKit

struct CoronaInfo {
    var deathCount: Int
    var infectedCount: Int
    var recoveryCount: Int
}

struct CoronaUpdateView: View {
    let coronaInfo: CoronaInfo
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.yellow)
            VStack(alignment: .leading) {
                HStack {
                    VStack(alignment:.leading) {
                            Text("Corona Update")
                                .foregroundColor(.black)
                                
                                .fontWeight(.light)
                                .font(Font.system(size: 25))
                                .multilineTextAlignment(.leading)
                                .lineSpacing(5)
                                .opacity(0.8)
                            
                    }
                    .frame(width: 100)
                    
                    Spacer()
                    ZStack(alignment:.trailing) {
                        Rectangle()
                            .opacity(0.8)
                        
                        VStack(alignment: .trailing, spacing: 3){
                            CoronaTitleView.init(title: "Infected")
                            CoronaCountView(count: coronaInfo.infectedCount)
                            CoronaTitleView.init(title: "Death")
                            CoronaCountView(count:coronaInfo.deathCount)
                            CoronaTitleView.init(title: "Recovered")
                            CoronaCountView(count: coronaInfo.recoveryCount)
                        }
                        .padding()
                    }
                }
                                
            }
        }
    }
}

struct CoronaUpdateView2_Previews: PreviewProvider {
    static var previews: some View {
        CoronaUpdateView(coronaInfo: CoronaInfo.init(deathCount: 12, infectedCount: 23, recoveryCount: 34))
            .previewContext(WidgetPreviewContext.init(family: .systemMedium))
    }
}

struct CoronaCountView: View {
    let count: Int
    var body: some View {
        HStack {
            Text("\(count)")
                .fontWeight(.ultraLight)
                .font(Font.system(size: 20))
                .foregroundColor(.white)
                .multilineTextAlignment(.trailing)
        }
    }
}

struct CoronaTitleView: View {
    let title: String
    var body: some View {
        HStack {
            Text(title)
                .font(Font.system(size: 13))
                .fontWeight(.medium)
                .foregroundColor(.white)
                .multilineTextAlignment(.trailing)
            
        }
    }
}
